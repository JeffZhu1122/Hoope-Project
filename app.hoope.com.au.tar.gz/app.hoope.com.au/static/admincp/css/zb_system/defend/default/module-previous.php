{foreach $articles as $article}
<li><a href="{$article.Url}">{$article.Title}</a></li>
{/foreach}
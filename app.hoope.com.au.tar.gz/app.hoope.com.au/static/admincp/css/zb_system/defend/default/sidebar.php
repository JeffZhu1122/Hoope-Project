{* Template Name:侧栏模板 *}
{foreach $sidebar as $module}
{template:module}
{/foreach}